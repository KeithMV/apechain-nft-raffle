// Fixed Lambda Image Proxy - Stage-Aware CORS
// Detects API Gateway stage and sets appropriate CORS headers

exports.handler = async (event) => {
    console.log('=== Lambda Image Proxy Started ===');
    console.log('Event:', JSON.stringify(event, null, 2));
    
    const imageUrl = event.queryStringParameters?.url;
    const owner = event.queryStringParameters?.owner;
    const chainId = event.queryStringParameters?.chainId;
    const contractAddress = event.queryStringParameters?.contractAddress;
    const tokenId = event.queryStringParameters?.tokenId;
    
    // DETECT ENVIRONMENT FROM API GATEWAY STAGE
    const stage = event.requestContext?.stage || 'prod';
    const environment = stage === 'staging' ? 'staging' : 'production';
    
    console.log('Detected stage:', stage);
    console.log('Environment:', environment);
    
    // Handle specific NFT metadata queries (Alchemy getNFTMetadata API)
    if (contractAddress && tokenId && chainId) {
        console.log('🔍 Specific NFT metadata query:', { contractAddress, tokenId, chainId });
        return await handleSpecificNFTQuery(contractAddress, tokenId, chainId, environment);
    }

    // Handle NFT ownership queries (Alchemy getNFTsForOwner API)
    if (owner && chainId) {
        console.log('🔍 NFT ownership query:', { owner, chainId });
        return await handleNFTOwnershipQuery(owner, chainId, environment);
    }
    
    // Handle image proxy requests
    if (!imageUrl) {
        console.log('❌ Missing URL parameter');
        return createErrorResponse(400, 'Missing url parameter', null, null, null, environment);
    }
    
    // SECURITY: Validate URL to prevent SSRF attacks
    if (!isValidUrl(imageUrl)) {
        console.log('❌ Invalid or unsafe URL:', imageUrl);
        return createErrorResponse(400, 'Invalid or unsafe URL provided', null, null, null, environment);
    }
    
    console.log('🔍 Fetching URL:', imageUrl);
    
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
            console.log('⏰ Request timeout after 8 seconds');
            controller.abort();
        }, 8000);
        
        const response = await fetch(imageUrl, {
            headers: {
                'User-Agent': `ApeChain-NFT-Raffle/2.0 (${environment})`,
                'Accept': '*/*',
                'Cache-Control': 'no-cache'
            },
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        console.log('📊 Response status:', response.status);
        console.log('📋 Response headers:', Object.fromEntries(response.headers.entries()));
        
        if (!response.ok) {
            console.log('❌ Response not OK:', response.status, response.statusText);
            return createErrorResponse(response.status, `HTTP ${response.status}: ${response.statusText}`, imageUrl, null, null, environment);
        }
        
        const contentType = response.headers.get('content-type') || 'application/octet-stream';
        console.log('📄 Content type:', contentType);
        
        // Handle JSON responses (metadata)
        if (contentType.includes('application/json') || contentType.includes('text/plain')) {
            const text = await response.text();
            console.log('✅ JSON response length:', text.length);
            
            // Validate JSON
            try {
                JSON.parse(text);
            } catch (jsonError) {
                console.log('⚠️ Invalid JSON response, treating as text');
            }
            
            return {
                statusCode: 200,
                headers: createCorsHeaders(environment, 'application/json'),
                body: text
            };
        }
        
        // Handle binary responses (images)
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        console.log('✅ Binary response size:', buffer.length, 'bytes');
        
        // Validate image size (max 10MB)
        if (buffer.length > 10 * 1024 * 1024) {
            console.log('❌ Image too large:', buffer.length);
            return createErrorResponse(413, 'Image too large (max 10MB)', null, buffer.length, null, environment);
        }
        
        return {
            statusCode: 200,
            headers: {
                ...createCorsHeaders(environment, contentType),
                'Content-Length': buffer.length.toString()
            },
            body: buffer.toString('base64'),
            isBase64Encoded: true
        };
        
    } catch (error) {
        console.error('💥 Error occurred:', error);
        console.error('Error name:', error.name);
        console.error('Error message:', error.message);
        
        let errorMessage = 'Proxy request failed';
        let statusCode = 500;
        
        if (error.name === 'AbortError') {
            errorMessage = 'Request timeout (8 seconds)';
            statusCode = 408;
        } else if (error.name === 'TypeError' && error.message.includes('fetch')) {
            errorMessage = 'Network connection failed';
            statusCode = 502;
        }
        
        return createErrorResponse(statusCode, errorMessage, imageUrl, null, error.message, environment);
    }
};

// SECURITY: URL validation to prevent SSRF attacks
function isValidUrl(url) {
    try {
        const parsedUrl = new URL(url);
        
        // Block private IP ranges and localhost
        const hostname = parsedUrl.hostname.toLowerCase();
        
        // Block localhost and private IPs
        if (hostname === 'localhost' || 
            hostname.startsWith('127.') ||
            hostname.startsWith('10.') ||
            hostname.startsWith('192.168.') ||
            hostname.startsWith('172.16.') ||
            hostname.startsWith('172.17.') ||
            hostname.startsWith('172.18.') ||
            hostname.startsWith('172.19.') ||
            hostname.startsWith('172.2') ||
            hostname.startsWith('172.30.') ||
            hostname.startsWith('172.31.') ||
            hostname === '169.254.169.254' || // AWS metadata service
            hostname.includes('metadata')) {
            console.log('🚫 Blocked private/internal URL:', hostname);
            return false;
        }
        
        // Only allow HTTPS
        if (parsedUrl.protocol !== 'https:') {
            console.log('🚫 Only HTTPS URLs allowed');
            return false;
        }
        
        // Allowlist trusted domains for NFT/IPFS content
        const trustedDomains = [
            // IPFS Gateways
            'ipfs.io',
            'gateway.pinata.cloud',
            'dweb.link',
            'cloudflare-ipfs.com',
            'gateway.ipfs.io',
            'cf-ipfs.com',
            'ipfs.infura.io',
            'ipfs.moralis.io',
            'nftstorage.link',
            'w3s.link',
            
            // Pinata domains (all subdomains)
            'mypinata.cloud',
            'pinata.cloud',
            'gateway.pinata.cloud',
            
            // Arweave
            'arweave.net',
            
            // NFT Platform APIs - Major Providers
            'cdn-api.niftykit.com',
            'api.niftykit.com',
            'niftykit.com',
            'metadata.niftykit.com',
            'api.thirdweb.com',
            'metadata.thirdweb.com',
            'thirdweb.com',
            'api.manifold.xyz',
            'metadata.manifold.xyz',
            'manifold.xyz',
            'api.async.art',
            'metadata.async.art',
            'async.art',
            
            // Major NFT Marketplaces
            'api.opensea.io',
            'opensea.io',
            'metadata.opensea.io',
            'looksrare.org',
            'api.looksrare.org',
            'rarible.com',
            'api.rarible.org',
            'foundation.app',
            'api.foundation.app',
            'metadata.foundation.app',
            'superrare.com',
            'api.superrare.com',
            
            // Storage & CDN Providers
            'storageapi.fleek.co',
            'gateway.fleek.co',
            'fleek.co',
            'storage.googleapis.com',
            'firebasestorage.googleapis.com',
            
            // Polygon-specific domains
            'polygon-metadata.s3.amazonaws.com',
            'assets.polygon.technology',
            'api.polygonscan.com',
            'metadata.polygonscan.com',
            
            // Ethereum/Multi-chain
            'img.op.xyz',
            'img.other.page',
            'api.other.page',
            'api.op.xyz',
            'api2.balloonsballoons.xyz',
            'metadata.ens.domains',
            
            // Additional metadata services
            'metadata.buildship.xyz',
            'buildship.xyz',
            'api.reservoir.tools',
            'reservoir.tools',
            'metadata.degods.com',
            'degods.com',
            
            // Common NFT Infrastructure
            'api.center.app',
            'center.app',
            'api.zora.co',
            'zora.co',
            'metadata.zora.co',
            'api.highlight.xyz',
            'highlight.xyz',
            'metadata.highlight.xyz',
            
            // Additional IPFS/Decentralized Storage
            'gateway.lighthouse.storage',
            'lighthouse.storage',
            'api.web3.storage',
            'web3.storage',
            'dweb.link',
            
            // AWS S3 buckets commonly used for NFT metadata
            's3.amazonaws.com',
            's3.us-east-1.amazonaws.com',
            's3.us-west-2.amazonaws.com',
            's3.eu-west-1.amazonaws.com',
            
            // Cloudflare domains for NFT projects
            'imagedelivery.net',
            'cdn.discordapp.com',
            
            // Additional NFT platforms
            'api.artblocks.io',
            'artblocks.io',
            'metadata.artblocks.io',
            'api.async.art',
            'metadata.async.art',
            
            // Gaming/Sandbox NFT platforms
            'contracts.sandbox.game',
            'api.sandbox.game',
            'metadata.sandbox.game',
            'sandbox.game'
        ];
        
        const isAllowed = trustedDomains.some(domain => hostname.includes(domain));
        if (!isAllowed) {
            console.log('🚫 Domain not in allowlist:', hostname);
        }
        
        return isAllowed;
    } catch (error) {
        console.log('🚫 Invalid URL format:', error.message);
        return false;
    }
}

// FIXED: Stage-aware CORS headers with localhost support
function createCorsHeaders(environment, contentType = 'application/json') {
    // For development/testing, allow all origins
    // For production, be more restrictive but still allow localhost for testing
    let allowedOrigin = '*';
    
    if (environment === 'production') {
        allowedOrigin = '*'; // Temporarily allow all for testing
    } else if (environment === 'staging') {
        allowedOrigin = '*'; // Allow all for staging
    }
    
    return {
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': allowedOrigin,
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Cache-Control': contentType.includes('image') ? 'public, max-age=86400' : 'public, max-age=3600'
    };
}

// Handle specific NFT metadata queries using Alchemy getNFTMetadata API
async function handleSpecificNFTQuery(contractAddress, tokenId, chainId, environment) {
    const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
    
    if (!ALCHEMY_API_KEY) {
        console.log('❌ Missing ALCHEMY_API_KEY environment variable');
        return createErrorResponse(500, 'Alchemy API not configured', null, null, null, environment);
    }
    
    const ALCHEMY_ENDPOINTS = {
        33139: 'https://apechain-mainnet.g.alchemy.com/nft/v3', // ApeChain
        137: 'https://polygon-mainnet.g.alchemy.com/nft/v3',   // Polygon
        1: 'https://eth-mainnet.g.alchemy.com/nft/v3',          // Ethereum
        42161: 'https://arb-mainnet.g.alchemy.com/nft/v3'       // Arbitrum
    };
    
    const endpoint = ALCHEMY_ENDPOINTS[chainId];
    if (!endpoint) {
        console.log('❌ Unsupported chain ID:', chainId);
        return createErrorResponse(400, `Unsupported chain ID: ${chainId}`, null, null, null, environment);
    }
    
    console.log(`📡 Fetching specific NFT metadata for chain ${chainId} (${chainId === 137 ? 'Polygon' : chainId === 33139 ? 'ApeChain' : 'Other'})`);
    const url = `${endpoint}/${ALCHEMY_API_KEY}/getNFTMetadata?contractAddress=${contractAddress}&tokenId=${tokenId}&refreshCache=false`;
    
    try {
        console.log('📡 Fetching NFT metadata from Alchemy:', { contractAddress, tokenId, chainId, endpoint: endpoint.split('/').slice(0, 3).join('/') + '/...' });
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
            console.log('⏰ Alchemy request timeout after 10 seconds');
            controller.abort();
        }, 10000);
        
        const response = await fetch(url, {
            headers: {
                'Accept': 'application/json',
                'User-Agent': `ApeChain-NFT-Raffle/2.0 (${environment})`
            },
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
            console.log('❌ Alchemy API error:', response.status, response.statusText);
            const errorText = await response.text();
            console.log('Error details:', errorText);
            return createErrorResponse(response.status, `Alchemy API error: ${response.statusText}`, null, null, null, environment);
        }
        
        const data = await response.json();
        console.log(`✅ Alchemy NFT metadata response for chain ${chainId}:`, { 
            hasMetadata: !!data.metadata, 
            hasImage: !!(data.media?.[0] || data.metadata?.image),
            title: data.title || data.name
        });
        
        // Transform Alchemy response to match expected format
        const nftData = {
            contractAddress: data.contract?.address || contractAddress,
            tokenId: data.tokenId || tokenId,
            name: data.title || data.name || data.metadata?.name || `NFT #${tokenId}`,
            description: data.description || data.metadata?.description || '',
            image: data.image?.cachedUrl || data.image?.originalUrl || data.media?.[0]?.gateway || data.media?.[0]?.raw || data.metadata?.image || '',
            metadata: {
                name: data.title || data.name || data.metadata?.name,
                description: data.description || data.metadata?.description,
                image: data.image?.cachedUrl || data.image?.originalUrl || data.media?.[0]?.gateway || data.media?.[0]?.raw || data.metadata?.image,
                attributes: data.metadata?.attributes || []
            }
        };
        
        console.log(`🖼️ Processed NFT metadata for ${contractAddress}/${tokenId}, image: ${!!nftData.image}`);
        
        return {
            statusCode: 200,
            headers: createCorsHeaders(environment),
            body: JSON.stringify({
                success: true,
                nft: nftData,
                chainId: parseInt(chainId),
                contractAddress: contractAddress,
                tokenId: tokenId,
                source: 'alchemy-metadata',
                timestamp: new Date().toISOString()
            })
        };
        
    } catch (error) {
        console.error('💥 Alchemy NFT metadata error:', error);
        
        let errorMessage = 'NFT metadata query failed';
        let statusCode = 500;
        
        if (error.name === 'AbortError') {
            errorMessage = 'Alchemy API timeout (10 seconds)';
            statusCode = 408;
        } else if (error.name === 'TypeError' && error.message.includes('fetch')) {
            errorMessage = 'Alchemy API connection failed';
            statusCode = 502;
        }
        
        return createErrorResponse(statusCode, errorMessage, null, null, error.message, environment);
    }
}

// Handle NFT ownership queries using Alchemy API
async function handleNFTOwnershipQuery(owner, chainId, environment) {
    const ALCHEMY_API_KEY = process.env.ALCHEMY_API_KEY;
    
    if (!ALCHEMY_API_KEY) {
        console.log('❌ Missing ALCHEMY_API_KEY environment variable');
        return createErrorResponse(500, 'Alchemy API not configured', null, null, null, environment);
    }
    
    const ALCHEMY_ENDPOINTS = {
        33139: 'https://apechain-mainnet.g.alchemy.com/nft/v3', // ApeChain
        137: 'https://polygon-mainnet.g.alchemy.com/nft/v3',   // Polygon
        1: 'https://eth-mainnet.g.alchemy.com/nft/v3',          // Ethereum
        42161: 'https://arb-mainnet.g.alchemy.com/nft/v3'       // Arbitrum
    };
    
    const endpoint = ALCHEMY_ENDPOINTS[chainId];
    if (!endpoint) {
        console.log('❌ Unsupported chain ID:', chainId);
        return createErrorResponse(400, `Unsupported chain ID: ${chainId}`, null, null, null, environment);
    }
    
    console.log(`📡 Fetching NFTs for chain ${chainId} (${chainId === 137 ? 'Polygon' : chainId === 33139 ? 'ApeChain' : 'Other'})`);
    const url = `${endpoint}/${ALCHEMY_API_KEY}/getNFTsForOwner?owner=${owner}&withMetadata=true&pageSize=100`;
    
    try {
        console.log('📡 Fetching NFTs from Alchemy:', { owner, chainId, endpoint: endpoint.split('/').slice(0, 3).join('/') + '/...' });
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
            console.log('⏰ Alchemy request timeout after 10 seconds');
            controller.abort();
        }, 10000);
        
        const response = await fetch(url, {
            headers: {
                'Accept': 'application/json',
                'User-Agent': `ApeChain-NFT-Raffle/2.0 (${environment})`
            },
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
            console.log('❌ Alchemy API error:', response.status, response.statusText);
            const errorText = await response.text();
            console.log('Error details:', errorText);
            return createErrorResponse(response.status, `Alchemy API error: ${response.statusText}`, null, null, null, environment);
        }
        
        const data = await response.json();
        console.log(`✅ Alchemy response for chain ${chainId}:`, { totalCount: data.totalCount, returned: data.ownedNfts?.length });
        
        // Transform Alchemy response to match our expected format
        const nfts = (data.ownedNfts || []).map(nft => {
            // Enhanced image URL processing for different chains
            let imageUrl = nft.media?.[0]?.gateway || nft.media?.[0]?.raw || '';
            
            // Special handling for Polygon NFTs with common metadata issues
            if (chainId === 137 && !imageUrl && nft.rawMetadata?.image) {
                imageUrl = nft.rawMetadata.image;
            }
            
            return {
                contractAddress: nft.contract.address,
                tokenId: nft.tokenId,
                name: nft.title || nft.name || `NFT #${nft.tokenId}`,
                description: nft.description || '',
                image: imageUrl,
                metadata: {
                    name: nft.title || nft.name,
                    description: nft.description,
                    image: imageUrl,
                    attributes: nft.rawMetadata?.attributes || []
                }
            };
        });
        
        console.log(`🖼️ Processed ${nfts.length} NFTs for chain ${chainId}, ${nfts.filter(n => n.image).length} with images`);
        
        return {
            statusCode: 200,
            headers: createCorsHeaders(environment),
            body: JSON.stringify({
                success: true,
                totalCount: data.totalCount || 0,
                nfts: nfts,
                chainId: parseInt(chainId),
                owner: owner,
                source: 'alchemy',
                timestamp: new Date().toISOString()
            })
        };
        
    } catch (error) {
        console.error('💥 Alchemy API error:', error);
        
        let errorMessage = 'NFT query failed';
        let statusCode = 500;
        
        if (error.name === 'AbortError') {
            errorMessage = 'Alchemy API timeout (10 seconds)';
            statusCode = 408;
        } else if (error.name === 'TypeError' && error.message.includes('fetch')) {
            errorMessage = 'Alchemy API connection failed';
            statusCode = 502;
        }
        
        return createErrorResponse(statusCode, errorMessage, null, null, error.message, environment);
    }
}

// FIXED: Standardized error response with environment parameter
function createErrorResponse(statusCode, message, url = null, size = null, originalError = null, environment = 'production') {
    return {
        statusCode: statusCode,
        headers: createCorsHeaders(environment),
        body: JSON.stringify({ 
            error: message,
            ...(url && { url }),
            ...(size && { size }),
            ...(originalError && environment !== 'production' && { originalError }),
            environment,
            timestamp: new Date().toISOString()
        })
    };
}